"use client";

import Image from "next/image";
import Link from "next/link";

/* ═══════════════════════════════════════════════════════
   LANDING PAGE — Distribuidora El Remate
   Paleta: tokens cálidos del branding v1.0
   ═══════════════════════════════════════════════════════ */

const SUCURSALES = [
  { nombre: "La Paz", telefono: "094 358 830", direccion: "Ramón Álvarez 225" },
  { nombre: "Las Piedras", telefono: "092 202 019", direccion: "Luis Alberto de Herrera 487" },
  { nombre: "18 de Mayo", telefono: "094 713 033", direccion: "Maestro Julio Castro 15" },
  { nombre: "Las Piedras", telefono: "099 013 272", direccion: "Avenida Artigas 750" },
  { nombre: "Canelones", telefono: "094 611 400", direccion: "General Artigas 118" },
  { nombre: "El Dorado", telefono: "093 404 158", direccion: "Elías Regules esq. Honduras" },
];

const CATEGORIAS = [
  { icono: "🫙", nombre: "Aceites y Aderezos" },
  { icono: "🌾", nombre: "Harinas, Pastas y Legumbres" },
  { icono: "☕", nombre: "Café, Té y Yerba" },
  { icono: "🥤", nombre: "Bebidas" },
  { icono: "🥛", nombre: "Lácteos" },
  { icono: "🥩", nombre: "Fiambres y Carnes" },
  { icono: "🍬", nombre: "Golosinas y Dulces" },
  { icono: "🧂", nombre: "Especias y Condimentos" },
  { icono: "🧹", nombre: "Limpieza" },
  { icono: "🧴", nombre: "Higiene Personal" },
  { icono: "❄️", nombre: "Congelados" },
  { icono: "🥫", nombre: "Conservas y Enlatados" },
];

const FEATURES = [
  {
    icono: "💰",
    titulo: "Precios Mayoristas",
    descripcion: "Todos los días los mejores precios para tu negocio o tu hogar",
  },
  {
    icono: "📦",
    titulo: "+800 Productos",
    descripcion: "Variedad completa en alimentos, bebidas, limpieza e insumos",
  },
  {
    icono: "🚚",
    titulo: "Envío a Domicilio",
    descripcion: "Recibí tu pedido en la puerta de tu casa o comercio",
  },
  {
    icono: "📱",
    titulo: "Pedí por WhatsApp",
    descripcion: "Rápido, práctico y pensado para vos. Hacé tu pedido ahora",
  },
];

export default function LandingPage() {
  return (
    <div style={{ fontFamily: "var(--font-body, 'DM Sans'), sans-serif" }}>
      {/* ══════ HERO ══════ */}
      <section
        style={{
          background: "var(--oscuro, #1A1410)",
          position: "relative",
          overflow: "hidden",
          minHeight: "90vh",
          display: "flex",
          alignItems: "center",
        }}
      >
        {/* Imagen de fondo */}
        <div style={{ position: "absolute", inset: 0, zIndex: 0 }}>
          <Image
            src="/hero-bg.jpg"
            alt="Distribuidora El Remate"
            fill
            priority
            style={{ objectFit: "cover", objectPosition: "center" }}
          />
          {/* Overlay oscuro cálido — contraste alto para texto claro */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              background:
                "linear-gradient(to right, rgba(26,20,16,0.96) 0%, rgba(26,20,16,0.82) 50%, rgba(26,20,16,0.45) 100%)",
            }}
          />
        </div>

        {/* Textura radial cálida */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            backgroundImage: `
              radial-gradient(ellipse 60% 80% at -5% 50%, rgba(214,40,40,0.14) 0%, transparent 55%),
              radial-gradient(ellipse 50% 60% at 105% 20%, rgba(214,40,40,0.08) 0%, transparent 50%)
            `,
            pointerEvents: "none",
            zIndex: 1,
          }}
        />

        {/* Contenido */}
        <div
          style={{
            position: "relative",
            zIndex: 2,
            width: "100%",
            maxWidth: "1200px",
            margin: "0 auto",
            padding: "80px 20px 60px",
            textAlign: "center",
          }}
        >
          {/* Logo */}
          <div style={{ marginBottom: "28px", display: "flex", justifyContent: "center" }}>
            <Image
              src="/logo.png"
              alt="Distribuidora El Remate"
              width={180}
              height={180}
              style={{
                objectFit: "contain",
                maxWidth: "80vw",
                height: "auto",
                filter: "drop-shadow(0 4px 20px rgba(214,40,40,0.3))",
              }}
              priority
            />
          </div>

          {/* Badge */}
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              marginBottom: "24px",
            }}
          >
            <span
              style={{
                background: "var(--rojo, #D62828)",
                color: "#fff",
                fontSize: "0.65rem",
                fontWeight: 700,
                letterSpacing: "2.5px",
                textTransform: "uppercase",
                padding: "4px 12px",
                borderRadius: "4px",
                boxShadow: "0 2px 8px rgba(214,40,40,0.4)",
              }}
            >
              Mayorista
            </span>
            <span
              style={{
                fontSize: "0.7rem",
                fontWeight: 600,
                letterSpacing: "3px",
                textTransform: "uppercase",
                color: "var(--rojo, #D62828)",
                opacity: 0.9,
              }}
            >
              Distribuidora · Canelones
            </span>
          </div>

          {/* Título */}
          <h1
            className="hero-title"
            style={{
              fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
              fontSize: "clamp(2.5rem, 8vw, 5.5rem)",
              letterSpacing: "3px",
              lineHeight: 0.9,
              color: "#fff",
              marginBottom: "20px",
              textShadow: "0 2px 20px rgba(0,0,0,0.5)",
            }}
          >
            PRECIOS MAYORISTAS
            <span
              style={{
                display: "block",
                color: "var(--rojo, #D62828)",
                textShadow: "0 0 30px rgba(214,40,40,0.4)",
              }}
            >
              TODOS LOS DÍAS
            </span>
          </h1>

          {/* Descriptor */}
          <p
            className="hero-descriptor"
            style={{
              fontSize: "clamp(0.95rem, 2.5vw, 1.2rem)",
              color: "rgba(255,255,255,0.85)",
              fontWeight: 500,
              maxWidth: "600px",
              lineHeight: 1.6,
              marginBottom: "32px",
              marginLeft: "auto",
              marginRight: "auto",
              textShadow: "0 1px 6px rgba(0,0,0,0.4)",
            }}
          >
            Todo para tu negocio y tu casa: alimentos, insumos, bebidas y limpieza al mejor precio.
          </p>

          {/* CTAs */}
          <div
            className="cta-buttons"
            style={{
              display: "flex",
              gap: "12px",
              flexWrap: "wrap",
              justifyContent: "center",
              marginBottom: "40px",
            }}
          >
            <Link
              href="/catalogo"
              style={{
                background: "var(--rojo, #D62828)",
                color: "#fff",
                borderRadius: "var(--r-md, 12px)",
                padding: "14px 32px",
                fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
                fontSize: "1.2rem",
                letterSpacing: "2px",
                textDecoration: "none",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                boxShadow: "0 4px 18px rgba(214,40,40,0.35)",
                transition: "all 0.15s",
              }}
            >
              🛒 VER CATÁLOGO
            </Link>
            <a
              href="https://wa.me/59894717052"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                background: "rgba(26,107,60,0.08)",
                color: "var(--verde, #1A6B3C)",
                border: "1.5px solid rgba(26,107,60,0.3)",
                borderRadius: "var(--r-md, 12px)",
                padding: "14px 28px",
                fontFamily: "var(--font-body, 'DM Sans'), sans-serif",
                fontSize: "0.9rem",
                fontWeight: 700,
                textDecoration: "none",
                display: "flex",
                alignItems: "center",
                gap: "8px",
                transition: "all 0.15s",
              }}
            >
              📱 WhatsApp
            </a>
          </div>

          {/* Stats */}
          <div
            className="hero-stats"
            style={{
              display: "inline-flex",
              border: "1px solid rgba(214,40,40,0.3)",
              borderRadius: "var(--r-sm, 8px)",
              overflow: "hidden",
              background: "rgba(26,20,16,0.5)",
              backdropFilter: "blur(8px)",
              flexWrap: "wrap",
            }}
          >
            {[
              { val: "800+", lbl: "Productos" },
              { val: "6", lbl: "Sucursales" },
              { val: "WA", lbl: "Pedido Express" },
            ].map((stat, i) => (
              <div
                key={i}
                className="hero-stat"
                style={{
                  padding: "12px 24px",
                  textAlign: "center",
                  borderRight: i < 2 ? "1px solid rgba(214,40,40,0.15)" : "none",
                }}
              >
                <div
                  style={{
                    fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
                    fontSize: "1.8rem",
                    color: "var(--rojo, #D62828)",
                    letterSpacing: "1px",
                    lineHeight: 1,
                    textShadow: "0 0 12px rgba(214,40,40,0.3)",
                  }}
                >
                  {stat.val}
                </div>
                <div
                  style={{
                    fontSize: "0.6rem",
                    fontWeight: 600,
                    textTransform: "uppercase",
                    letterSpacing: "1px",
                    color: "rgba(255,255,255,0.6)",
                    marginTop: "4px",
                  }}
                >
                  {stat.lbl}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════ TICKER ══════ */}
      <div
        style={{
          background: "var(--oscuro-2, #2C2318)",
          borderTop: "1px solid rgba(214,40,40,0.12)",
          borderBottom: "1px solid rgba(214,40,40,0.12)",
          overflow: "hidden",
          padding: "10px 0",
        }}
      >
        <div
          style={{
            display: "flex",
            animation: "tickerScroll 32s linear infinite",
            whiteSpace: "nowrap",
          }}
        >
          {[...Array(2)].map((_, idx) => (
            <span key={idx} style={{ display: "flex" }}>
              {[
                "⚡ Precios de distribuidor",
                "📦 Pedí por WhatsApp",
                "🏠 Zona Canelones",
                "🛒 Más de 800 productos",
                "✅ Fiambres · Congelados · Limpieza",
                "🚚 Envío a domicilio",
              ].map((item, i) => (
                <span
                  key={i}
                  style={{
                    fontSize: "0.68rem",
                    fontWeight: 600,
                    letterSpacing: "1.5px",
                    textTransform: "uppercase",
                    color: "var(--crema, #F5F0E8)",
                    opacity: 0.55,
                    padding: "0 32px",
                    flexShrink: 0,
                  }}
                >
                  {item}
                  <span style={{ color: "var(--rojo, #D62828)", margin: "0 4px", opacity: 2 }}>
                    ★
                  </span>
                </span>
              ))}
            </span>
          ))}
        </div>
        <style>{`
          @keyframes tickerScroll {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
          }
        `}</style>
      </div>

      {/* ══════ FEATURES ══════ */}
      <section
        style={{
          padding: "80px 20px",
          background: "var(--crema, #F5F0E8)",
        }}
      >
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: "48px" }}>
            <h2
              style={{
                fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
                fontSize: "clamp(2rem, 5vw, 3rem)",
                color: "var(--oscuro, #1A1410)",
                letterSpacing: "2px",
                marginBottom: "8px",
              }}
            >
              COMPRÁ FÁCIL
            </h2>
            <p
              style={{
                fontFamily: "var(--font-serif, 'DM Serif Display'), serif",
                fontStyle: "italic",
                fontSize: "1.1rem",
                color: "var(--tierra, #5C4A35)",
              }}
            >
              Rápido, práctico y pensado para vos
            </p>
          </div>

          <div
            className="features-grid"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
              gap: "20px",
            }}
          >
            {FEATURES.map((feature, i) => (
              <div
                key={i}
                style={{
                  background: "var(--white, #FFFFFF)",
                  borderRadius: "var(--r-lg, 16px)",
                  border: "1.5px solid var(--border, #E8DDD0)",
                  padding: "28px 24px",
                  textAlign: "center",
                  transition: "all 0.2s",
                  boxShadow: "var(--shadow-sm)",
                }}
              >
                <div style={{ fontSize: "2.5rem", marginBottom: "16px" }}>
                  {feature.icono}
                </div>
                <h3
                  style={{
                    fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
                    fontSize: "1.5rem",
                    color: "var(--oscuro, #1A1410)",
                    letterSpacing: "1px",
                    marginBottom: "8px",
                  }}
                >
                  {feature.titulo}
                </h3>
                <p
                  style={{
                    fontSize: "0.85rem",
                    color: "var(--tierra, #5C4A35)",
                    lineHeight: 1.6,
                  }}
                >
                  {feature.descripcion}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════ CATEGORÍAS ══════ */}
      <section
        style={{
          padding: "80px 20px",
          background: "var(--crema, #F5F0E8)",
        }}
      >
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: "48px" }}>
            <span
              style={{
                fontSize: "11px",
                fontWeight: 700,
                letterSpacing: "4px",
                textTransform: "uppercase",
                color: "var(--muted, #9C8570)",
                display: "block",
                marginBottom: "8px",
              }}
            >
              Catálogo
            </span>
            <h2
              style={{
                fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
                fontSize: "clamp(2rem, 5vw, 3rem)",
                color: "var(--oscuro, #1A1410)",
                letterSpacing: "2px",
                marginBottom: "8px",
              }}
            >
              VARIEDAD DE PRODUCTOS
            </h2>
            <p
              style={{
                fontFamily: "var(--font-serif, 'DM Serif Display'), serif",
                fontStyle: "italic",
                fontSize: "1.1rem",
                color: "var(--tierra, #5C4A35)",
              }}
            >
              Todo lo que necesitás en un solo lugar
            </p>
          </div>

          <div
            className="categorias-grid"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))",
              gap: "10px",
            }}
          >
            {CATEGORIAS.map((cat, i) => (
              <Link
                key={i}
                href="/catalogo"
                style={{
                  background: "var(--white, #FFFFFF)",
                  borderRadius: "var(--r-md, 12px)",
                  border: "1.5px solid var(--border, #E8DDD0)",
                  padding: "20px 12px",
                  textAlign: "center",
                  textDecoration: "none",
                  transition: "all 0.15s",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: "8px",
                }}
              >
                <span style={{ fontSize: "2rem" }}>{cat.icono}</span>
                <span
                  style={{
                    fontSize: "0.68rem",
                    fontWeight: 700,
                    color: "var(--tierra, #5C4A35)",
                    textTransform: "uppercase",
                    letterSpacing: "0.5px",
                    lineHeight: 1.3,
                  }}
                >
                  {cat.nombre}
                </span>
              </Link>
            ))}
          </div>

          <div style={{ textAlign: "center", marginTop: "40px" }}>
            <Link
              href="/catalogo"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "8px",
                background: "var(--oscuro, #1A1410)",
                color: "#fff",
                border: "none",
                borderRadius: "var(--r-md, 12px)",
                padding: "14px 32px",
                fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
                fontSize: "1.2rem",
                letterSpacing: "2px",
                textDecoration: "none",
                transition: "all 0.15s",
              }}
            >
              VER CATÁLOGO COMPLETO →
            </Link>
          </div>
        </div>
      </section>

      {/* ══════ PEDIDO ONLINE ══════ */}
      <section
        style={{
          padding: "80px 20px",
          background: "var(--white, #FFFFFF)",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            position: "relative",
            zIndex: 2,
            maxWidth: "900px",
            margin: "0 auto",
            textAlign: "center",
          }}
        >
          <span
            style={{
              fontSize: "11px",
              fontWeight: 700,
              letterSpacing: "4px",
              textTransform: "uppercase",
              color: "var(--muted, #9C8570)",
              display: "block",
              marginBottom: "8px",
            }}
          >
            Hacé tu pedido
          </span>
          <h2
            style={{
              fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
              fontSize: "clamp(2.5rem, 6vw, 4rem)",
              color: "var(--oscuro, #1A1410)",
              letterSpacing: "2px",
              marginBottom: "8px",
            }}
          >
            PEDÍ
            <span style={{ color: "var(--rojo, #D62828)" }}> ¡ONLINE!</span>
          </h2>
          <p
            style={{
              fontFamily: "var(--font-serif, 'DM Serif Display'), serif",
              fontStyle: "italic",
              fontSize: "1.15rem",
              color: "var(--tierra, #5C4A35)",
              lineHeight: 1.7,
              marginBottom: "40px",
              maxWidth: "600px",
              marginLeft: "auto",
              marginRight: "auto",
            }}
          >
            Navegá por el catálogo, agregá lo que querés y enviá tu pedido por WhatsApp.
          </p>

          {/* Steps */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
              gap: "20px",
              marginBottom: "40px",
            }}
          >
            {[
              { step: "1", icono: "🛒", titulo: "ELEGÍ", desc: "Navegá por el catálogo y seleccioná tus productos" },
              { step: "2", icono: "📝", titulo: "ARMÁ", desc: "Revisá tu pedido y ajustá cantidades si es necesario" },
              { step: "3", icono: "📱", titulo: "ENVIÁ", desc: "Enviá tu pedido por WhatsApp y coordiná la entrega" },
            ].map((step, i) => (
              <div
                key={i}
                style={{
                  background: "var(--white, #FFFFFF)",
                  border: "1.5px solid var(--border, #E8DDD0)",
                  borderRadius: "var(--r-lg, 16px)",
                  padding: "28px 20px",
                  position: "relative",
                  boxShadow: "var(--shadow-sm)",
                }}
              >
                <div
                  style={{
                    position: "absolute",
                    top: "-12px",
                    left: "50%",
                    transform: "translateX(-50%)",
                    background: "var(--rojo, #D62828)",
                    color: "#fff",
                    width: "28px",
                    height: "28px",
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
                    fontSize: "1.1rem",
                  }}
                >
                  {step.step}
                </div>
                <div style={{ fontSize: "2.5rem", marginBottom: "12px", marginTop: "8px" }}>
                  {step.icono}
                </div>
                <h3
                  style={{
                    fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
                    fontSize: "1.4rem",
                    color: "var(--rojo, #D62828)",
                    letterSpacing: "1px",
                    marginBottom: "8px",
                  }}
                >
                  {step.titulo}
                </h3>
                <p
                  style={{
                    fontSize: "0.82rem",
                    color: "var(--tierra, #5C4A35)",
                    lineHeight: 1.5,
                  }}
                >
                  {step.desc}
                </p>
              </div>
            ))}
          </div>

          <p
            style={{
              fontSize: "0.9rem",
              color: "var(--muted, #9C8570)",
              marginBottom: "32px",
            }}
          >
            También podés visitarnos en cualquiera de nuestras 6 sucursales en Canelones.
          </p>

          <div
            style={{
              display: "flex",
              gap: "12px",
              justifyContent: "center",
              flexWrap: "wrap",
            }}
          >
            <Link
              href="/catalogo"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "8px",
                background: "var(--rojo, #D62828)",
                color: "#fff",
                borderRadius: "var(--r-md, 12px)",
                padding: "16px 36px",
                fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
                fontSize: "1.3rem",
                letterSpacing: "2px",
                textDecoration: "none",
                boxShadow: "0 4px 18px rgba(214,40,40,0.35)",
                transition: "all 0.15s",
              }}
            >
              🛒 IR AL CATÁLOGO
            </Link>
            <a
              href="https://wa.me/59894717052"
              target="_blank"
              rel="noopener noreferrer"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "8px",
                background: "rgba(26,107,60,0.08)",
                color: "var(--verde, #1A6B3C)",
                border: "1.5px solid rgba(26,107,60,0.3)",
                borderRadius: "var(--r-md, 12px)",
                padding: "16px 28px",
                fontFamily: "var(--font-body, 'DM Sans'), sans-serif",
                fontSize: "0.95rem",
                fontWeight: 700,
                textDecoration: "none",
                transition: "all 0.15s",
              }}
            >
              📱 CONSULTAR POR WHATSAPP
            </a>
          </div>
        </div>
      </section>

      {/* ══════ SUCURSALES ══════ */}
      <section
        style={{
          padding: "80px 20px",
          background: "var(--crema, #F5F0E8)",
        }}
      >
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: "48px" }}>
            <h2
              style={{
                fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
                fontSize: "clamp(2rem, 5vw, 3rem)",
                color: "var(--oscuro, #1A1410)",
                letterSpacing: "2px",
                marginBottom: "8px",
              }}
            >
              NUESTRAS SUCURSALES
            </h2>
            <p
              style={{
                fontFamily: "var(--font-serif, 'DM Serif Display'), serif",
                fontStyle: "italic",
                fontSize: "1.1rem",
                color: "var(--tierra, #5C4A35)",
              }}
            >
              Encontranos en Canelones
            </p>
          </div>

          <div
            className="sucursales-grid"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
              gap: "16px",
            }}
          >
            {SUCURSALES.map((sucursal, i) => (
              <div
                key={i}
                style={{
                  background: "var(--white, #FFFFFF)",
                  borderRadius: "var(--r-lg, 16px)",
                  border: "1.5px solid var(--border, #E8DDD0)",
                  padding: "24px",
                  boxShadow: "var(--shadow-sm)",
                  transition: "all 0.15s",
                }}
              >
                <h3
                  style={{
                    fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
                    fontSize: "1.5rem",
                    color: "var(--oscuro, #1A1410)",
                    letterSpacing: "1px",
                    marginBottom: "12px",
                  }}
                >
                  {sucursal.nombre}
                </h3>
                <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                  <p
                    style={{
                      fontSize: "0.85rem",
                      color: "var(--tierra, #5C4A35)",
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                    }}
                  >
                    📍 {sucursal.direccion}
                  </p>
                  <a
                    href={`https://wa.me/598${sucursal.telefono.replace(/\s/g, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      fontSize: "0.85rem",
                      color: "var(--rojo-dark, #B01E1E)",
                      textDecoration: "none",
                      fontWeight: 600,
                      display: "flex",
                      alignItems: "center",
                      gap: "8px",
                    }}
                  >
                    📱 {sucursal.telefono}
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══════ CONTACTO CTA ══════ */}
      <section
        style={{
          padding: "60px 20px",
          background: "var(--oscuro, #1A1410)",
          textAlign: "center",
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Glow decorativo cálido */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: "radial-gradient(ellipse 60% 80% at 50% 120%, rgba(214,40,40,0.12) 0%, transparent 60%)",
            pointerEvents: "none",
          }}
        />
        <div style={{ maxWidth: "600px", margin: "0 auto", position: "relative", zIndex: 1 }}>
          <h2
            style={{
              fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
              fontSize: "clamp(1.8rem, 4vw, 2.5rem)",
              color: "#fff",
              letterSpacing: "2px",
              marginBottom: "12px",
            }}
          >
            ¿TENÉS DUDAS O QUERÉS HACER UN PEDIDO?
          </h2>
          <p
            style={{
              fontSize: "1rem",
              color: "rgba(255,255,255,0.6)",
              marginBottom: "28px",
            }}
          >
            Contactanos por WhatsApp y te respondemos al instante
          </p>
          <a
            href="https://wa.me/59894717052"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "10px",
              background: "var(--verde, #1A6B3C)",
              color: "#fff",
              borderRadius: "var(--r-md, 12px)",
              padding: "16px 32px",
              fontFamily: "var(--font-display, 'Bebas Neue'), sans-serif",
              fontSize: "1.3rem",
              letterSpacing: "2px",
              textDecoration: "none",
              boxShadow: "0 4px 18px rgba(26,107,60,0.35)",
              transition: "all 0.15s",
            }}
          >
            📱 094 717 052
          </a>
        </div>
      </section>

      {/* ══════ FOOTER ══════ */}
      <footer
        style={{
          background: "var(--oscuro, #1A1410)",
          padding: "32px 20px",
          textAlign: "center",
          borderTop: "1px solid var(--oscuro-3, #3D3226)",
        }}
      >
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <div style={{ marginBottom: "16px" }}>
            <Image
              src="/logo.png"
              alt="Distribuidora El Remate"
              width={60}
              height={60}
              style={{ objectFit: "contain", opacity: 0.6 }}
            />
          </div>
          <p style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.35)", marginBottom: "6px" }}>
            Copyright © 2026 Distribuidora El Remate. Todos los derechos reservados.
          </p>
          <p style={{ fontSize: "0.65rem", color: "rgba(255,255,255,0.2)" }}>
            Powered by Dafna y Mateo Asencio
          </p>
        </div>
      </footer>

      {/* ── Responsive ── */}
      <style jsx global>{`
        @media (max-width: 768px) {
          .hero-title { font-size: 2.5rem !important; }
          .hero-stats { flex-direction: column !important; width: 100% !important; }
          .hero-stat {
            border-right: none !important;
            border-bottom: 1px solid rgba(214,40,40,0.15) !important;
            padding: 12px !important;
          }
          .hero-stat:last-child { border-bottom: none !important; }
          .features-grid,
          .categorias-grid,
          .sucursales-grid { grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)) !important; }
        }
        @media (max-width: 480px) {
          .hero-title { font-size: 2rem !important; }
          .hero-descriptor { font-size: 0.9rem !important; }
          .cta-buttons { flex-direction: column !important; }
        }
      `}</style>
    </div>
  );
}
