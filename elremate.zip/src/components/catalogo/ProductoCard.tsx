"use client";

import React, { useRef, useCallback } from "react";
import type { Producto } from "@/types";
import { EMOJI_POR_CATEGORIA } from "@/types";

interface ProductoCardProps {
  producto: Producto;
  qty: number;
  searchTerm?: string;
  onAdd: (producto: Producto) => void;
  onQtyChange: (codigo: string, qty: number) => void;
}

function formatPrice(n: number): string {
  return `$${n.toLocaleString("es-UY", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
}

/* ── Map categorías a colores CSS ─────────────────────── */
function getCatColorVar(cat: string): string {
  const map: Record<string, string> = {
    "Aceites y Aderezos": "var(--cat-aceites, #92400E)",
    "Bebidas": "var(--cat-bebidas, #1D4ED8)",
    "Café, Té y Yerba": "var(--cat-cafe, #3B1C07)",
    "Cereales y Granola": "var(--cat-cereales, #D97706)",
    "Congelados": "var(--cat-congelados, #0369A1)",
    "Conservas de Pescado": "var(--cat-pescado, #0F766E)",
    "Conservas y Enlatados": "var(--cat-pescado, #0F766E)",
    "Descartables y Embalaje": "var(--cat-descart, #6B7280)",
    "Especias y Condimentos": "var(--cat-especias, #065F46)",
    "Fiambres y Carnes": "var(--cat-fiambres, #991B1B)",
    "Golosinas y Dulces": "var(--cat-golosinas, #7C3AED)",
    "Harinas, Pastas y Legumbres": "var(--cat-harinas, #78350F)",
    "Higiene Personal": "var(--cat-higiene, #0891B2)",
    "Lácteos": "var(--cat-lacteos, #B45309)",
    "Limpieza": "var(--cat-limpieza, #0E7490)",
    "Mermeladas y Conservas Dulces": "var(--cat-mermeladas, #BE185D)",
    "Otros": "var(--cat-otros, #6B7280)",
    "Panadería": "var(--cat-panaderia, #2A6B3E)",
    "Papel e Higiene": "var(--cat-papel, #475569)",
  };
  return map[cat] || "var(--border, #E8DDD0)";
}

/* ── Color tenue para badge de categoría ──────────────── */
function getCatBgTint(cat: string): string {
  const map: Record<string, string> = {
    "Aceites y Aderezos": "#FEF3C7",
    "Bebidas": "#EFF6FF",
    "Café, Té y Yerba": "#FEF3C7",
    "Cereales y Granola": "#FEF3C7",
    "Congelados": "#E0F2FE",
    "Conservas de Pescado": "#F0FDFA",
    "Descartables y Embalaje": "#F3F4F6",
    "Especias y Condimentos": "#ECFDF5",
    "Fiambres y Carnes": "#FEF2F2",
    "Golosinas y Dulces": "#F5F3FF",
    "Harinas, Pastas y Legumbres": "#FEF3C7",
    "Higiene Personal": "#ECFEFF",
    "Lácteos": "#FEF3C7",
    "Limpieza": "#ECFEFF",
    "Mermeladas y Conservas Dulces": "#FDF2F8",
    "Otros": "#F3F4F6",
    "Panadería": "#F0FDF4",
    "Papel e Higiene": "#F8FAFC",
  };
  return map[cat] || "#F5F0E8";
}

function highlightText(text: string, searchTerm: string | undefined): React.ReactNode {
  if (!searchTerm || !searchTerm.trim()) return text;

  const regex = new RegExp(`(${searchTerm.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
  const parts = text.split(regex);

  return parts.map((part, i) =>
    regex.test(part) ? (
      <mark key={i} style={{
        background: "var(--ambar-pale, rgba(217,119,6,0.18))",
        color: "var(--texto, #1A1410)",
        borderRadius: "2px",
        padding: "0 1px",
      }}>
        {part}
      </mark>
    ) : part
  );
}

export default function ProductoCard({ producto, qty, searchTerm, onAdd, onQtyChange }: ProductoCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const isInCart = qty > 0;

  const handleAdd = useCallback(() => {
    onAdd(producto);
    // Trigger pop animation
    const el = cardRef.current;
    if (el) {
      el.classList.remove("popped");
      // Force reflow
      void el.offsetWidth;
      el.classList.add("popped");
    }
  }, [onAdd, producto]);

  const handleDec = useCallback(() => {
    onQtyChange(producto.codigo, Math.max(0, qty - 1));
  }, [onQtyChange, producto.codigo, qty]);

  const handleInc = useCallback(() => {
    onQtyChange(producto.codigo, qty + 1);
  }, [onQtyChange, producto.codigo, qty]);

  const emoji = EMOJI_POR_CATEGORIA[producto.categoria] || "\ud83d\udce6";
  const catColor = getCatColorVar(producto.categoria);
  const catBg = getCatBgTint(producto.categoria);

  return (
    <div
      ref={cardRef}
      className={`card${isInCart ? " in-cart" : ""}`}
      style={{ "--cat-color": catColor } as React.CSSProperties}
    >
      {/* Thumbnail */}
      <div className="card-thumb">
        <span role="img" aria-hidden="true">{emoji}</span>
      </div>

      {/* Body */}
      <div className="card-body">
        {/* Category badge */}
        <span style={{
          display: "inline-block",
          fontSize: "0.52rem",
          fontWeight: 800,
          letterSpacing: "1px",
          textTransform: "uppercase",
          background: catBg,
          color: catColor,
          padding: "2px 7px",
          borderRadius: "4px",
          marginBottom: "6px",
          maxWidth: "100%",
          whiteSpace: "nowrap",
          overflow: "hidden",
          textOverflow: "ellipsis",
        }}>
          {producto.categoria}
        </span>

        <div className="card-name">
          {highlightText(producto.nombre, searchTerm)}
        </div>
        <div className="card-price">{formatPrice(producto.precio)}</div>
        <div className="card-price-label">precio unidad</div>

        {/* Actions */}
        <div className="card-actions">
          {isInCart ? (
            <div className="qty-ctrl">
              <button className="qty-btn" onClick={handleDec} aria-label="Reducir cantidad">
                &#8722;
              </button>
              <span className="qty-val">{qty}</span>
              <button
                className="qty-btn"
                onClick={handleInc}
                aria-label="Aumentar cantidad"
                style={{ background: "var(--verde)", color: "#fff", border: "none" }}
              >
                +
              </button>
            </div>
          ) : (
            <button
              className="btn-add"
              onClick={handleAdd}
              style={{ background: "var(--rojo)" }}
            >
              + Agregar
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
