"use client";

import { useEffect, useState, useCallback, useMemo, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { useProductos } from "@/hooks/useProductos";
import { useCart } from "@/lib/cart-context";
import { useAuth } from "@/lib/auth-context";
import { useToast } from "@/lib/toast-context";
import { usePedidosLocales } from "@/hooks/usePedidosLocales";
import { usePedidosCloud } from "@/hooks/usePedidosCloud";
import { useOnline } from "@/hooks/useOnline";
import {
  Hero,
  Ticker,
  CatsNav,
  ResultsBar,
  ProductoGrid,
  FloatCartBtn,
} from "@/components/catalogo";
import CartPanel from "@/components/carrito/CartPanel";
import UserPanel from "@/components/usuario/UserPanel";
import ConfirmModal from "@/components/carrito/ConfirmModal";
import OnlineBanner from "@/components/ui/OnlineBanner";
import {
  armarMensajeWA,
  enviarWhatsApp,
} from "@/lib/whatsapp";
import {
  guardarPedidoGlobal,
  incrementarStats,
} from "@/lib/pedidos";
import { encodeCartToURL, decodeCartFromURL } from "@/lib/cart-share";
import { haptic } from "@/lib/haptic";
import * as ls from "@/lib/ls";
import type { Vista, CartItem, Producto } from "@/types";

/* ── Shared cart banner (shown when ?cart= URL param) ── */
function SharedCartBanner({
  sharedCart,
  onLoad,
  onIgnore,
}: {
  sharedCart: CartItem[] | null;
  onLoad: () => void;
  onIgnore: () => void;
}) {
  if (!sharedCart) return null;

  return (
    <div
      style={{
        background: "var(--ambar-pale, rgba(248,150,30,0.14))",
        border: "1.5px solid rgba(248,150,30,0.35)",
        borderRadius: "var(--r-md, 12px)",
        margin: "12px 16px",
        padding: "12px 16px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "12px",
        flexWrap: "wrap",
      }}
    >
      <span style={{ fontSize: "0.82rem", fontWeight: 600, color: "var(--text)" }}>
        Se carg\u00f3 un pedido compartido ({sharedCart.length} productos)
      </span>
      <div style={{ display: "flex", gap: "8px" }}>
        <button
          onClick={onLoad}
          style={{
            background: "var(--oscuro, #1A1410)",
            color: "#fff",
            border: "none",
            borderRadius: "var(--r-sm, 8px)",
            padding: "6px 14px",
            fontFamily: "var(--font-body), sans-serif",
            fontSize: "0.78rem",
            fontWeight: 700,
            cursor: "pointer",
          }}
        >
          Cargar este pedido
        </button>
        <button
          onClick={onIgnore}
          style={{
            background: "transparent",
            color: "var(--muted, #9C8570)",
            border: "1.5px solid var(--border, #E8DDD0)",
            borderRadius: "var(--r-sm, 8px)",
            padding: "6px 14px",
            fontFamily: "var(--font-body), sans-serif",
            fontSize: "0.78rem",
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          Ignorar
        </button>
      </div>
    </div>
  );
}

/**
 * Suspense-wrapped component that reads useSearchParams.
 * Must be rendered inside a Suspense boundary.
 */
function SharedCartWatcher({
  onLoadCart,
}: {
  onLoadCart: (cart: CartItem[]) => void;
}) {
  const searchParams = useSearchParams();

  useEffect(() => {
    const cartParam = searchParams?.get("cart");
    if (cartParam) {
      const decoded = decodeCartFromURL(cartParam);
      if (decoded && decoded.length > 0) {
        onLoadCart(decoded);
      }
    }
    // Only on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return null;
}

/* ── Main Catalog Page ── */
export default function CatalogoPage() {
  // Hooks
  const {
    productos,
    loading: loadingProductos,
    filtrados,
    categorias,
    search,
    setSearch,
    categoria,
    setCategoria,
  } = useProductos();

  const { items: cartItems, addItem, removeItem, updateQty, clearCart, total, totalQty } = useCart();
  const { user, signOut } = useAuth();
  const toast = useToast();
  const isOnline = useOnline();

  // Local state
  const [cartOpen, setCartOpen] = useState(false);
  const [userPanelOpen, setUserPanelOpen] = useState(false);
  const [vista, setVista] = useState<Vista>(() => ls.getVista());
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);
  const [alias, setAlias] = useState(() => ls.getAlias());
  const [clientNotes, setClientNotes] = useState("");
  const [sharedCart, setSharedCart] = useState<CartItem[] | null>(null);
  const [shareLink, setShareLink] = useState<string | null>(null);

  // Cloud orders (when logged in)
  const { pedidos: cloudPedidos } = usePedidosCloud();
  // Local orders (guest)
  const { pedidos: localPedidos, savePedido: saveLocalPedido } = usePedidosLocales();

  // Qty map for product grid
  const qtyMap = useMemo(() => {
    const map: Record<string, number> = {};
    cartItems.forEach((i) => {
      map[i.codigo] = i.cantidad;
    });
    return map;
  }, [cartItems]);

  // Handlers
  const handleAddProduct = useCallback(
    (producto: Producto) => {
      addItem(producto);
      haptic.add();
    },
    [addItem]
  );

  const handleQtyChange = useCallback(
    (codigo: string, qty: number) => {
      if (qty <= 0) {
        removeItem(codigo);
        haptic.remove();
      } else {
        const current = qtyMap[codigo] || 0;
        const delta = qty - current;
        if (delta > 0) {
          for (let i = 0; i < delta; i++) addItem({ codigo, nombre: "", precio: 0 });
        } else {
          for (let i = 0; i < -delta; i++) updateQty(codigo, -1);
        }
      }
    },
    [qtyMap, addItem, removeItem, updateQty]
  );

  const handleToggleVista = useCallback((v: Vista) => {
    setVista(v);
    ls.setVista(v);
  }, []);

  const handleSaveAlias = useCallback((a: string) => {
    setAlias(a);
    ls.setAlias(a);
  }, []);

  const handleClearData = useCallback(() => {
    ls.setAlias("");
    ls.setHistory([]);
    ls.setBusquedas([]);
    setAlias("");
    toast.info("Datos locales limpiados");
  }, [toast]);

  const handleLogout = useCallback(async () => {
    await signOut();
    toast.info("Sesi\u00f3n cerrada");
  }, [signOut, toast]);

  const handleReorder = useCallback(
    (pedido: { items: { codigo: string; nombre: string; cantidad: number; precioUnitario?: number; precio?: number }[]; total: number }) => {
      if (totalQty === 0) {
        // Cart empty: load directly
        pedido.items.forEach((item) => {
          for (let i = 0; i < item.cantidad; i++) {
            addItem({ codigo: item.codigo, nombre: item.nombre, precio: item.precioUnitario ?? item.precio ?? 0 });
          }
        });
        setUserPanelOpen(false);
        toast.success("Cargado. Revis\u00e1 antes de enviar.");
      } else {
        // Cart has items: show modal (simplified: just add)
        pedido.items.forEach((item) => {
          for (let i = 0; i < item.cantidad; i++) {
            addItem({ codigo: item.codigo, nombre: item.nombre, precio: item.precioUnitario ?? item.precio ?? 0 });
          }
        });
        setUserPanelOpen(false);
        toast.success("Productos agregados al carrito.");
      }
    },
    [totalQty, addItem, toast]
  );

  const handleShareCart = useCallback(() => {
    const encoded = encodeCartToURL(cartItems);
    if (!encoded) return;
    const url = `${window.location.origin}/catalogo?cart=${encoded}`;
    setShareLink(url);
    toast.info("Link generado. Copialo desde el carrito.");
  }, [cartItems, toast]);

  const handleCopyShareLink = useCallback(() => {
    if (shareLink) {
      navigator.clipboard.writeText(shareLink).then(() => {
        toast.success("Link copiado al portapapeles");
      });
    }
  }, [shareLink, toast]);

  // Send WA flow
  const handleSendWA = useCallback(() => {
    setCartOpen(false);
    setConfirmModalOpen(true);
  }, []);

  const handleConfirmSend = useCallback(() => {
    setConfirmModalOpen(false);
    haptic.send();

    const nombre = alias || "Cliente";
    const mensaje = armarMensajeWA(nombre, cartItems, clientNotes);
    const waNumber = process.env.NEXT_PUBLIC_WA_NUMBER || "";
    enviarWhatsApp(waNumber, mensaje);

    // Non-blocking: save order
    const pedidoItems = cartItems.map((i) => ({
      codigo: i.codigo,
      nombre: i.nombre,
      cantidad: i.cantidad,
      precioUnitario: i.precio,
    }));

    // Save to /pedidos_globales (non-blocking)
    guardarPedidoGlobal({
      uid: user?.uid ?? null,
      clienteNombre: nombre,
      items: pedidoItems,
      total,
      notas: clientNotes || undefined,
    }).catch((err) => console.warn("Failed to save pedido global:", err));

    // Increment stats (non-blocking)
    const codigos = cartItems.map((i) => i.codigo);
    incrementarStats(codigos).catch((err) =>
      console.warn("Failed to increment stats:", err)
    );

    // Save to localStorage history
    saveLocalPedido(cartItems, total, clientNotes || undefined);

    // Clear cart
    clearCart();

    toast.success("\u00a1Listo! Te esperamos pronto. \ud83d\ude4c");
  }, [alias, cartItems, clientNotes, total, user, clearCart, saveLocalPedido, toast]);

  const handleLoadSharedCart = useCallback(() => {
    if (sharedCart) {
      sharedCart.forEach((item) => {
        for (let i = 0; i < item.cantidad; i++) {
          addItem({ codigo: item.codigo, nombre: item.nombre, precio: item.precio });
        }
      });
      setSharedCart(null);
      toast.success("Pedido compartido cargado al carrito.");
    }
  }, [sharedCart, addItem, toast]);

  const handleIgnoreSharedCart = useCallback(() => {
    setSharedCart(null);
  }, []);

  // Use cloud pedidos when logged in, local when guest
  const pedidos = user ? cloudPedidos : localPedidos;

  // Determine active category for CatsNav
  const activeCat = categoria || (categorias.length > 0 ? categorias[0] : "");

  // Loading state
  if (loadingProductos) {
    return (
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "var(--oscuro, #1A1410)",
        }}
      >
        <div
          style={{
            width: "48px",
            height: "48px",
            border: "4px solid rgba(76, 201, 240, 0.15)",
            borderTopColor: "var(--rojo, #D62828)",
            borderRadius: "50%",
            animation: "spin 0.8s linear infinite",
          }}
        />
        <style>{`
          @keyframes spin { to { transform: rotate(360deg); } }
        `}</style>
      </div>
    );
  }

  return (
    <>
      <OnlineBanner />

      {/* Shared cart watcher (reads URL params inside Suspense) */}
      <Suspense fallback={null}>
        <SharedCartWatcher onLoadCart={(cart) => setSharedCart(cart)} />
      </Suspense>

      {/* Shared cart banner */}
      <SharedCartBanner
        sharedCart={sharedCart}
        onLoad={handleLoadSharedCart}
        onIgnore={handleIgnoreSharedCart}
      />

      {/* Hero */}
      <Hero
        onOpenCart={() => setCartOpen(true)}
        cartQty={totalQty}
        cartTotal={total}
        onOpenUser={() => setUserPanelOpen(true)}
        onShareCart={cartItems.length > 0 ? handleShareCart : undefined}
        isLoggedIn={!!user}
        searchQuery={search}
        onSearchChange={setSearch}
      />

      {/* Ticker */}
      <Ticker />

      {/* Category nav */}
      {categorias.length > 0 && (
        <CatsNav
          categorias={["Todos", ...categorias]}
          activeCat={activeCat}
          onSelect={(cat) => setCategoria(cat === "Todos" ? "" : cat)}
        />
      )}

      {/* Results bar */}
      <ResultsBar
        showing={Math.min(filtrados.length, 40)}
        total={filtrados.length}
        vista={vista}
        onToggleVista={handleToggleVista}
      />

      {/* Product grid/list */}
      <ProductoGrid
        productos={filtrados}
        vista={vista}
        qtyMap={qtyMap}
        searchTerm={search}
        onAdd={handleAddProduct}
        onQtyChange={handleQtyChange}
      />

      {/* Float cart button */}
      <FloatCartBtn
        totalQty={totalQty}
        total={total}
        onClick={() => setCartOpen(true)}
      />

      {/* Cart Panel */}
      <CartPanel
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cartItems}
        onUpdateQty={updateQty}
        onRemove={removeItem}
        total={total}
        onSendWA={handleSendWA}
        alias={alias}
        onAliasChange={handleSaveAlias}
        onShare={handleShareCart}
        onClear={() => {
          clearCart();
          toast.info("Carrito limpiado");
        }}
        shareLink={shareLink}
        onCopyShareLink={handleCopyShareLink}
        clientNotes={clientNotes}
        onClientNotesChange={setClientNotes}
      />

      {/* User Panel */}
      <UserPanel
        isOpen={userPanelOpen}
        onClose={() => setUserPanelOpen(false)}
        alias={alias}
        user={user}
        pedidos={pedidos}
        onAliasSave={handleSaveAlias}
        onReorder={handleReorder}
        onLogout={handleLogout}
        onClearData={handleClearData}
      />

      {/* Confirm Modal */}
      <ConfirmModal
        isOpen={confirmModalOpen}
        items={cartItems}
        total={total}
        onConfirm={handleConfirmSend}
        onCancel={() => setConfirmModalOpen(false)}
      />
    </>
  );
}
