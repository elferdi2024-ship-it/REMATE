'use client';

interface CartFooterProps {
  total: number;
  alias: string;
  onAliasChange: (alias: string) => void;
  onSendWA: () => void;
  onShare: () => void;
  onClear: () => void;
  shareLink: string | null;
  onCopyShareLink: () => void;
  clientNotes?: string;
  onClientNotesChange?: (notes: string) => void;
  onSaveLista?: () => void;
}

export default function CartFooter({
  total,
  alias,
  onAliasChange,
  onSendWA,
  onShare,
  onClear,
  shareLink,
  onCopyShareLink,
  clientNotes,
  onClientNotesChange,
  onSaveLista,
}: CartFooterProps) {
  return (
    <div className="cart-footer">
      {/* ── Total ── */}
      <div className="cart-total-section">
        <div className="cart-total-row">
          <span className="cart-total-label">Total estimado</span>
          <span className="cart-total-amount">${total.toLocaleString('es-UY')}</span>
        </div>
        <div className="cart-disclaimer">* Los precios son estimativos y pueden variar.</div>
      </div>

      {/* ── Share ── */}
      <div className="cart-share-section">
        <button className="btn-share-cart" onClick={onShare}>
          🔗 Compartir este pedido por WhatsApp
        </button>
        {shareLink && (
          <div className="share-link-row">
            <input
              type="text"
              className="share-link-input"
              value={shareLink}
              readOnly
            />
            <button className="btn-copy-link" onClick={onCopyShareLink}>
              Copiar
            </button>
          </div>
        )}
      </div>

      {/* ── Order form ── */}
      <div className="cart-order-section">
        <div className="cart-section-title">Completá tu pedido</div>

        <label className="field-label" htmlFor="clientName">
          👤 Tu nombre o negocio
        </label>
        <input
          id="clientName"
          type="text"
          className="field-input"
          placeholder="Ej: Almacén Don Pepe"
          value={alias}
          onChange={(e) => onAliasChange(e.target.value)}
          style={{ marginBottom: '10px' }}
        />

        {onClientNotesChange && (
          <>
            <label className="field-label" htmlFor="clientNotes">
              📝 Notas del pedido (opcional)
            </label>
            <textarea
              id="clientNotes"
              className="field-input"
              placeholder="Entregar en depósito trasero, horario preferido..."
              value={clientNotes || ''}
              onChange={(e) => onClientNotesChange(e.target.value)}
              rows={2}
              style={{ marginBottom: '10px', resize: 'vertical' }}
            />
          </>
        )}

        {onSaveLista && (
          <button className="btn-save-lista" onClick={onSaveLista}>
            Guardar como lista ↗
          </button>
        )}

        {/* ── WhatsApp Button ── */}
        <button className="btn-whatsapp" onClick={onSendWA}>
          <WhatsAppIcon />
          <div className="btn-whatsapp-text">
            <span className="btn-wa-main">ENVIAR PEDIDO</span>
            <span className="btn-wa-sub">Abre WhatsApp al instante</span>
          </div>
        </button>
      </div>

      {/* ── Clear cart ── */}
      <div style={{ padding: '8px 16px 14px' }}>
        <button className="btn-clear-cart" onClick={onClear}>
          Limpiar carrito
        </button>
      </div>
    </div>
  );
}

function WhatsAppIcon() {
  return (
    <svg viewBox="0 0 24 24">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z" />
      <path d="M12 0C5.373 0 0 5.373 0 12c0 2.025.507 3.932 1.395 5.608L0 24l6.538-1.373A11.936 11.936 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-1.923 0-3.728-.5-5.287-1.375l-.378-.225-3.88.816.824-3.787-.248-.39A9.956 9.956 0 012 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z" />
    </svg>
  );
}
